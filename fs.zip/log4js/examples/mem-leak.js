"use strict";
var log4js = require('../lib/log4js');
log4js.configure({
  appenders: [
    {
      type: 'stdout',
      category: "console"
    }, //控制台输出
    {
      type: "dateFile",
      filename: 'log4jstest.log',
      pattern: "_yyyy-MM-dd",
      alwaysIncludePattern: false,
      category: 'dateFileLog'
    }//日期文件格式
  ],
  replaceConsole: true, //INFO,DEBUG,ERROR,WARN
  levels:{
    dateFileLog: 'DEBUG'
  }
});
var logger = log4js.getLogger('dateFileLog');
// log every 30ms
var tid = setInterval(function () {
  logger.debug("cheese and crackers");
  console.log('some other logging thing.');
}, 10);

// stop after 30s
setTimeout(function() {
  clearInterval(tid);
}, 30000);
