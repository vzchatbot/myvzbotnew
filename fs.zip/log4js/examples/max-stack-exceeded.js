"use strict";
var log4js = require('../lib/log4js');
log4js.replaceConsole();

this.getLogger = function(name) {
   log4js.configure(__dirname + '/log.json', { reloadSecs: 300 });
   this.logger = log4js.getLogger(name);
   this.logger.debug("Logger successfully initialized.");
   return this.logger;
};

this.getLogger('cheese');
this.logger.error('does this break things?');
