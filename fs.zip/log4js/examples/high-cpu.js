"use strict";
var log4js = require('../lib/log4js');
log4js.configure('./high-cpu.conf', { reloadSecs: 300 });
